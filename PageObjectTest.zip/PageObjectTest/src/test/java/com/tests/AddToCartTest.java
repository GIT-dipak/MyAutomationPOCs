package com.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.base.BaseTest;
import com.pages.HomePage;
import com.pages.LoginPage;
import com.pages.ProductPage;

public class AddToCartTest extends BaseTest {

	@Test
	public void testAddItemToCart() {
		test = extent.createTest("Add Item to Cart Test");
        driver.get("https://www.saucedemo.com/v1/index.html");
        
		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.login("standard_user", "secret_sauce"); 

		ProductPage productPage = homePage.goToProductPage();
		productPage.addItemToCart();

		Assert.assertTrue(productPage.isItemAddedToCart(), "The item was not added to the cart.");
	}
}
