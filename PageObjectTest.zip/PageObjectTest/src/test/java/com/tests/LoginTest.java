package com.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.base.BaseTest;
import com.pages.HomePage;
import com.pages.LoginPage;

public class LoginTest extends BaseTest {
	
	@Test
    public void testSuccessfulLogin() {
        test = extent.createTest("Successful Login Test");
        driver.get("https://www.saucedemo.com/v1/index.html");
        
        LoginPage loginPage = new LoginPage(driver);
        loginPage.enterUsername("standard_user");
        loginPage.enterPassword("secret_sauce");
        loginPage.clickLogin();
        
        HomePage homePage = new HomePage(driver);
        String title = homePage.getProductsTitle();
        
        test.info("Checking the title of the product page.");
        Assert.assertEquals(title, "Products", "Login failed or the Products page did not load.");
        
        test.pass("Test for successful login passed.");
    }

}
