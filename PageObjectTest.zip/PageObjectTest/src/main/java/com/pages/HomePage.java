package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage {
	private WebDriver driver;
	private By productsTitle = By.className("product_label");

	public HomePage(WebDriver driver) {
		this.driver = driver;
	}

	public String getProductsTitle() {
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return driver.findElement(productsTitle).getText();
	}

	public ProductPage goToProductPage() {
		driver.findElement(By.cssSelector(".inventory_item_name")).click(); // Clicking the first product
		return new ProductPage(driver);
	}
}
