package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ProductPage {
	private WebDriver driver;

	public ProductPage(WebDriver driver) {
		this.driver = driver;
	}

	private By addToCartButton = By.xpath("(//button[text()=\"ADD TO CART\"])[1]");

	public void addItemToCart() {
		WebElement addButton = driver.findElement(addToCartButton);
		addButton.click();
	}

	public boolean isItemAddedToCart() {
		try {
			WebElement cartBadge = driver.findElement(By.cssSelector(".shopping_cart_badge"));
			return cartBadge.isDisplayed();
		} catch (Exception e) {
			return false;
		}
	}

}
