package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;
import java.util.Set;

public class HomePage {
	private WebDriver driver;
	private WebDriverWait wait;

	@FindBy(xpath = "//span[@class='commonModal__close']")
	private WebElement closePopup;

	@FindBy(xpath = "//li[@data-cy='menu_Hotels']")
	private WebElement hotelsTab;

	@FindBy(xpath = "//input[@id='city']")
	private WebElement cityDropdown;

	@FindBy(xpath = "//li[@id='react-autowhatever-1-section-0-item-0']//b[contains(text(),'Ahme')]")
	private WebElement searchResultClick;

	@FindBy(xpath = "//label[@for='checkin']")
	private WebElement checkinField;

	@FindBy(xpath = "//label[@for='checkout']")
	private WebElement checkoutField;

	@FindBy(xpath = "//button[@data-cy='submit']")
	private WebElement searchButton;

	@FindBy(xpath = "(//button[normalize-space()='BOOK THIS NOW'])[1]")
	private String clickBookNow;

	@FindBy(xpath = "//a[normalize-space()='Pay Now']")
	private WebElement clickPayNow;
	
	@FindBy(xpath = "//span[normalize-space()='Credit & Debit Cards']")
	private WebElement clickCreditDebit;
	

	public HomePage(WebDriver driver) {
		this.driver = driver;
		this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		PageFactory.initElements(driver, this);
	}

	public void closeLoginPopup() {
		try {
			if (wait.until(ExpectedConditions.visibilityOf(closePopup)).isDisplayed()) {
				System.out.println("[INFO] Closing the login popup.");
				closePopup.click();
				System.out.println("[SUCCESS] Login popup closed.");
			}
		} catch (TimeoutException e) {
			System.out.println("[INFO] No login popup detected, proceeding.");
		}
	}

	public void clickOnHotelsTab() {
		System.out.println("[INFO] Clicking on the Hotels tab.");
		wait.until(ExpectedConditions.elementToBeClickable(hotelsTab)).click();
		System.out.println("[SUCCESS] Hotels tab clicked.");
	}

	public void selectCity() {
		try {
			System.out.println("[INFO] Selecting city: Ahmedabad.");
			cityDropdown.click();
			WebElement activeInputField = wait.until(ExpectedConditions
					.elementToBeClickable(By.xpath("//input[@placeholder='Where do you want to stay?']")));
			activeInputField.sendKeys("Ahmedabad");
			wait.until(ExpectedConditions.elementToBeClickable(searchResultClick)).click();
			System.out.println("[SUCCESS] City selected: Ahmedabad.");
		} catch (TimeoutException e) {
			System.out.println("[ERROR] City selection failed.");
		}
	}

	public void selectCheckInDate(String expectedMonthYear, String day) {
		clickDateField(checkinField);
		selectDate(expectedMonthYear, day);
	}

	public void selectCheckOutDate(String expectedMonthYear, String day) {
		clickDateField(checkoutField);
		selectDate(expectedMonthYear, day);
	}

	private void clickDateField(WebElement dateField) {
		try {
			wait.until(ExpectedConditions.elementToBeClickable(dateField)).click();
		} catch (ElementClickInterceptedException e) {
			System.out.println("[WARNING] Date field not clickable, using JavaScript.");
			((JavascriptExecutor) driver).executeScript("arguments[0].click();", dateField);
		}
	}

	private void selectDate(String expectedMonthYear, String day) {
		try {
			System.out.println("[INFO] Selecting date: " + day + " in " + expectedMonthYear);

			while (true) {
				WebElement displayedMonthYear = wait.until(
						ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='DayPicker-Caption']")));

				// Fix: Ensure correct format before comparison
				String displayedText = displayedMonthYear.getText().trim().replaceAll("([a-zA-Z]+)(\\d{4})", "$1 $2");

				System.out.println(
						"Currently displayed: [" + displayedText + "] | Expected: [" + expectedMonthYear + "]");

				if (displayedText.equalsIgnoreCase(expectedMonthYear.trim())) {
					System.out.println("Desired month found: " + displayedText);
					break;
				}

				WebElement nextButton = driver.findElement(By.xpath("//span[@aria-label='Next Month']"));
				if (nextButton.isDisplayed() && nextButton.isEnabled()) {
					nextButton.click();
					Thread.sleep(1000); // Small delay for stability
				} else {
					System.out.println("[ERROR] Next Month button is not available.");
					return;
				}
			}
			WebElement dateElement = wait.until(
					ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(@aria-label, '" + day + "')]")));
			dateElement.click();
			System.out.println("[SUCCESS] Date selected: " + day + " in " + expectedMonthYear);

		} catch (Exception e) {
			System.out.println("[ERROR] Failed to select date: " + e.getMessage());
		}
	}

	public void clickSearchButton() {
		try {
			System.out.println("[INFO] Clicking the search button.");
			wait.until(ExpectedConditions.elementToBeClickable(searchButton)).click();
			System.out.println("[SUCCESS] Search initiated.");
		} catch (ElementClickInterceptedException e) {
			System.out.println("[WARNING] Search button not directly clickable, using JavaScript.");
			((JavascriptExecutor) driver).executeScript("arguments[0].click();", searchButton);
		}
	}

	public void selectHotelAndSwitchToNewTab(String hotelName) throws InterruptedException {
		String parentWindow = driver.getWindowHandle();

		try {
			System.out.println("[INFO] Waiting for hotel listing: " + hotelName);
			WebElement hotelElement = wait.until(ExpectedConditions
					.visibilityOfElementLocated(By.xpath("//span[contains(text(),'" + hotelName + "')]")));
			hotelElement.click();
			System.out.println("[SUCCESS] Clicked on hotel: " + hotelName);
		} catch (TimeoutException e) {
			System.out.println("[ERROR] Hotel not found: " + hotelName);
			return;
		}

		Thread.sleep(2000); // Allow new tab to open

		Set<String> allWindows = driver.getWindowHandles();
		for (String window : allWindows) {
			if (!window.equals(parentWindow)) {
				driver.switchTo().window(window);
				System.out.println("[INFO] Switched to new tab: " + driver.getTitle());
				break;
			}
		}
	}

	public void clickBookNow() {
		try {
			WebElement bookNowButton = wait.until(ExpectedConditions
					.elementToBeClickable(By.xpath("//button[normalize-space()='BOOK THIS NOW']")));

			// Scroll to the button before clicking (optional)
			((JavascriptExecutor) driver).executeScript(
					"arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'});", bookNowButton);
			Thread.sleep(2000); // Small pause for visibility

			bookNowButton.click();
			System.out.println("[SUCCESS] Clicked 'BOOK THIS NOW'.");

		} catch (TimeoutException e) {
			System.out.println("[ERROR] 'BOOK THIS NOW' button not found.");
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void scrollToFirstNameField() {
		try {
			WebElement firstNameElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("fName")));

			((JavascriptExecutor) driver).executeScript(
					"arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'});", firstNameElement);
			Thread.sleep(500); // Small pause for visibility

			System.out.println("[SUCCESS] Scrolled to the First Name field.");
		} catch (TimeoutException | InterruptedException e) {
			System.out.println("[ERROR] First Name field not found.");
		}
	}

	public void selectGuestTitle(String title) {
		try {
			WebElement titleDropdown = wait.until(ExpectedConditions.elementToBeClickable(By.id("title")));

			// Scroll into view if needed
			((JavascriptExecutor) driver).executeScript(
					"arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'});", titleDropdown);
			Thread.sleep(500);

			titleDropdown.click(); // Click on the dropdown

			Select select = new Select(titleDropdown);
			select.selectByVisibleText(title); // Select by visible text (Mr., Ms., Mrs.)

			System.out.println("[SUCCESS] Selected guest title: " + title);
		} catch (TimeoutException | InterruptedException e) {
			System.out.println("[ERROR] Guest title dropdown not found.");
		}
	}

	public void enterFirstName(String firstName) {
		try {
			WebElement firstNameField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("fName")));

			((JavascriptExecutor) driver).executeScript(
					"arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'});", firstNameField);
			Thread.sleep(500);

			firstNameField.clear(); // Clear existing text if any
			firstNameField.sendKeys(firstName); // Enter the first name

			System.out.println("[SUCCESS] Entered first name: " + firstName);
		} catch (TimeoutException | InterruptedException e) {
			System.out.println("[ERROR] First name field not found.");
		}
	}

	public void enterLastName(String lastName) {
		try {
			WebElement lastNameField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("lName")));

			((JavascriptExecutor) driver).executeScript(
					"arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'});", lastNameField);
			Thread.sleep(500);

			lastNameField.clear(); // Clear existing text if any
			lastNameField.sendKeys(lastName); // Enter the last name

			System.out.println("[SUCCESS] Entered last name: " + lastName);
		} catch (TimeoutException | InterruptedException e) {
			System.out.println("[ERROR] Last name field not found.");
		}
	}

	public void enterEmail(String email) {
		try {
			WebElement emailField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("email")));

			((JavascriptExecutor) driver)
					.executeScript("arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'});", emailField);
			Thread.sleep(500);

			emailField.clear(); // Clear existing text if any
			emailField.sendKeys(email); // Enter the email

			System.out.println("[SUCCESS] Entered email: " + email);
		} catch (TimeoutException | InterruptedException e) {
			System.out.println("[ERROR] Email field not found.");
		}
	}

	public void enterMobileNumber(String mNo) {
		try {
			WebElement mobileNumberField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("mNo")));
			((JavascriptExecutor) driver).executeScript(
					"arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'});", mobileNumberField);
			Thread.sleep(500);
			mobileNumberField.clear(); // Clear existing text if any
			mobileNumberField.sendKeys(mNo); // Enter the email
			System.out.println("[SUCCESS] Entered email: " + mNo);
		} catch (TimeoutException | InterruptedException e) {
			System.out.println("[ERROR] Email field not found.");
		}
	}

	public void selectInsuranceOption(String option) {
		try {
			String xpath = option.equalsIgnoreCase("yes")
					? "(//input[@type='radio' and @class='RadioButton-module_radioBtn__6HwEf'])[1]"
					: "(//input[@type='radio' and @class='RadioButton-module_radioBtn__6HwEf'])[2]";

			WebElement insuranceOption = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(xpath)));

			((JavascriptExecutor) driver).executeScript(
					"arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'});", insuranceOption);
			Thread.sleep(2000);

			insuranceOption.click();
			System.out.println("[SUCCESS] Selected insurance option: " + option);

		} catch (TimeoutException | InterruptedException e) {
			System.out.println("[ERROR] Insurance option '" + option + "' not found.");
		}
	}

	public void selectPaymentOption(String paymentType) {
		WebElement fullAmountRadio = driver.findElement(By.xpath("(//input[@type='radio' and @name='payGroup'])[1]"));
		WebElement zeroAmountRadio = driver.findElement(By.xpath("(//input[@type='radio' and @name='payGroup'])[2]"));

		if ("full".equalsIgnoreCase(paymentType)) {
			// Select full amount option
			if (!fullAmountRadio.isSelected()) {
				fullAmountRadio.click();
			}
		} else if ("zero".equalsIgnoreCase(paymentType)) {
			// Select zero amount option
			if (!zeroAmountRadio.isSelected()) {
				zeroAmountRadio.click();
			}
		} else {
			System.out.println("Invalid payment type. Use 'full' or 'zero'.");
		}
	}

	public void clickPayNow() throws InterruptedException {
		Thread.sleep(2000);
		clickPayNow.click();
		Thread.sleep(4000);

	}
	
	public void clickCreditDebitCard() {
		clickCreditDebit.click();
	}
}
