package testcases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import pages.HomePage;
import java.time.Duration;

public class HotelBookingTest {
	private WebDriver driver;
	private HomePage homePage;

	@BeforeClass
	public void setUp() {
		System.out.println("Setting up WebDriver...");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://www.makemytrip.com/");
		homePage = new HomePage(driver);

		// Assert URL loaded correctly
		Assert.assertEquals(driver.getCurrentUrl(), "https://www.makemytrip.com/",
				"[ERROR] URL did not load correctly.");
	}

	@Test(priority = 1)
	public void testClosePopup() {
		homePage.closeLoginPopup();
		System.out.println("[ASSERT] Popup closed or not displayed.");
		Assert.assertTrue(true, "Popup should be closed or not present.");
	}

	@Test(priority = 2)
	public void testClickHotelsTab() {
		homePage.clickOnHotelsTab();
		Assert.assertTrue(driver.getCurrentUrl().contains("hotels"), "[ERROR] Did not navigate to Hotels section.");
	}

	@Test(priority = 3)
	public void testSelectCity() {
		homePage.selectCity();
		System.out.println("[ASSERT] City should be selected.");
		Assert.assertTrue(true, "City selection should be successful.");
	}

	@Test(priority = 4)
	public void testSelectCheckInDate() {
		homePage.selectCheckInDate("March 2025", "15");
		System.out.println("[ASSERT] Check-in date should be selected.");
		Assert.assertTrue(true, "Check-in date selection should be successful.");
	}

	@Test(priority = 5)
	public void testSelectCheckOutDate() {
		homePage.selectCheckOutDate("March 2025", "20");
		System.out.println("[ASSERT] Check-out date should be selected.");
		Assert.assertTrue(true, "Check-out date selection should be successful.");
	}

	@Test(priority = 6)
	public void testClickSearchButton() {
		homePage.clickSearchButton();
		System.out.println("[ASSERT] Search should be triggered.");
		Assert.assertTrue(true, "Search should be initiated successfully.");
	}

	@Test(priority = 7)
	public void testSelectHotel() throws InterruptedException {
		homePage.selectHotelAndSwitchToNewTab("Taj Skyline");

		// Assert the new tab is opened and switched successfully
//		Assert.assertTrue(driver.getTitle().contains("Taj Skyline"), "[ERROR] Failed to switch to hotel details page.");
	}

	@Test(priority = 8)
	public void clickBookNow() {
		homePage.clickBookNow();
		System.out.println("[ASSERT] Book Now button should be clicked.");
		Assert.assertTrue(true, "Book Now button click should be successful.");
	}

	@Test(priority = 9)

	public void scrollToFirstNameField() {
		homePage.scrollToFirstNameField();
	}

	@Test(priority = 10)
	public void selectGuestTitle() {
		homePage.selectGuestTitle("Mr");
	}

	@Test(priority = 11)

	public void enterFirstName() {
		homePage.enterFirstName("Dipak");
	}

	@Test(priority = 11)

	public void enterLastName() {
		homePage.enterLastName("Pavar");
	}

	@Test(priority = 12)
	public void enterEmail() {
		homePage.enterEmail("test@gmail.com");
	}

	@Test(priority = 13)
	public void enterMobileNumber() {
		homePage.enterMobileNumber("0123456789");
	}

	@Test(priority = 14)
	public void selectInsuranceOption() {
		homePage.selectInsuranceOption("Yes");
	}

	@Test(priority = 15)
	public void selectPaymentOption() {
		homePage.selectPaymentOption("Full");
	}

	@Test(priority = 16)
	public void clickPayNow() {
		try {
			homePage.clickPayNow();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Test(priority = 17)
	public void clickCreditDebitCard() {
	
			homePage.clickCreditDebitCard();
		
	}
	

	@AfterClass
	public void tearDown() {
		System.out.println("Closing browser...");
		driver.quit();
	}

}
